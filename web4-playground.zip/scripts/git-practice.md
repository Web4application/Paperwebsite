# Git Practice

Try these tasks:

1. Create a branch named `practice/yourname`.
2. Modify index.html.
3. Commit with message "practice: updated html".
4. Push and open a PR.
5. Resolve a merge conflict by editing two branches.
