#!/bin/bash
git clone https://github.com/octocat/Spoon-Knife.git test-clone
echo "Clone complete."
