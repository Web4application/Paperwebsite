# Web4 Playground — Training Repo 🛠️✨

Welcome to the official **Web4Application Training Sandbox**, built for:
- Git & GitHub learning  
- Fork → Edit → Commit → PR practice  
- CI/CD testing  
- API playground  
- New developer onboarding  
- Demo integrations with Aura, RODA, Fadaka, Kubu-hai, Lola, and more  

This repo is intentionally **simple**, **safe**, and **fun** to use.
